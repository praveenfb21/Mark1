﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Razorpagesmovie.Models
{
    public class RazorpagesmovieContext : DbContext
    {
        public RazorpagesmovieContext (DbContextOptions<RazorpagesmovieContext> options)
            : base(options)
        {
        }

        public DbSet<Razorpagesmovie.Models.Movie> Movie { get; set; }
    }
}
